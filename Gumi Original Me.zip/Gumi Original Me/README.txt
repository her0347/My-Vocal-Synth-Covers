Thank you for downloading and using my SVP!

Please credit me by mentioning my artist name (samui-p) or linking my YouTube channel. 

Also please do comment a link to your cover under the video you got the SVP from - I want to see what you do with it! (◠ω◠)